# 1. Motivation

Ein Mini-Oszilloskop. Warum? Braucht man vielleicht mal für remote-überwachung von Geräten.  
