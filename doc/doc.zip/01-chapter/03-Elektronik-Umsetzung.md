# Elektronik


## Analoges Interface für die Messung:

Für die Spannungsmessung:

Isolierender Transformator und Operationsverstäker:

![ZMPT101B](./../02-pictures/ZMPT101B.png){ width=40% }


Für die Strommessung: 

Berührungsfrei mit Messwandler, auch mit opAmp:

![ZMCT103C](./../02-pictures/ZMCT103C.png){ width=40% }
