
\maketitle

\hbox{\vrule height .2pt width 39.14pc}
\vskip 8.5pt

Es soll ein Gerät am Netz gemessen werden. Netzrückwirkungen sollen berücksichtigt werden.

\hbox{\vrule height .2pt width 39.14pc}
\vskip 8.5pt
