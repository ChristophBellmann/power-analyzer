!include-header ./art.yaml

!include ./../01-chapter/101-Artikel-Einleitung.md

!include ./../01-chapter/02-Konzept.md

!include ./../01-chapter/03-Elektronik-Umsetzung.md

!include ./../01-chapter/04-Software-Umsetzung.md

!include ./../01-chapter/102-Artikel-Schlußwort.md
